#ifndef SI_PAIR_H
#define SI_PAIR_H

#include <string>

typedef struct {
    std::string first;
    int second;
} siPair;

#endif